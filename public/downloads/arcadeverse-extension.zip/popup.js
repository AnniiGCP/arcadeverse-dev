/**
 * ArcadeVerse — Arcade Points Calculator
 * Chrome Extension Popup Logic (Manifest V3)
 *
 * Uses the Canonical Arcade Calculation Engine (`canonical-calculator.js`)
 * to guarantee 100% calculation parity with the ArcadeVerse Dashboard.
 */

// Configuration
const API_PRIMARY = "https://arcadeverse.vercel.app/api/calculate-points";
const API_LOCAL_FALLBACK = "http://localhost:3001/api/calculate-points";
const WEB_BASE_URL = "https://arcadeverse.vercel.app";
const CACHE_MIN_REFRESH_INTERVAL_MS = 25 * 1000; // 25s deduplication

// Storage keys
const STORAGE_KEYS = {
  PROFILE_URL: "arcadeverse_profile_url",
  IS_FACILITATOR: "arcadeverse_is_facilitator",
  CACHED_DATA: "arcadeverse_cached_data",
  LAST_SUCCESS_TIME: "arcadeverse_last_success_time",
  LAST_FETCH_TIME: "arcadeverse_last_fetch_time",
};

// DOM Elements
const elements = {
  // Views
  setupView: document.getElementById("setupView"),
  dashboardView: document.getElementById("dashboardView"),
  statusBanner: document.getElementById("statusBanner"),
  statusMessage: document.getElementById("statusMessage"),
  retryBtn: document.getElementById("retryBtn"),

  // Auto detect
  autoDetectBanner: document.getElementById("autoDetectBanner"),
  autoDetectUrl: document.getElementById("autoDetectUrl"),
  useDetectedUrlBtn: document.getElementById("useDetectedUrlBtn"),

  // Buttons
  refreshBtn: document.getElementById("refreshBtn"),
  inlineRefreshBtn: document.getElementById("inlineRefreshBtn"),
  changeProfileBtn: document.getElementById("changeProfileBtn"),
  viewFullDashboardBtn: document.getElementById("viewFullDashboardBtn"),
  openArcadeVerseBtn: document.getElementById("openArcadeVerseBtn"),

  // Setup Form
  profileForm: document.getElementById("profileForm"),
  profileUrlInput: document.getElementById("profileUrlInput"),
  isFacilitatorInput: document.getElementById("isFacilitatorInput"),
  calculateSubmitBtn: document.getElementById("calculateSubmitBtn"),
  inputError: document.getElementById("inputError"),

  // Dashboard Items
  userAvatar: document.getElementById("userAvatar"),
  userName: document.getElementById("userName"),
  userMemberSince: document.getElementById("userMemberSince"),
  userLeagueBadge: document.getElementById("userLeagueBadge"),
  totalPointsValue: document.getElementById("totalPointsValue"),
  swagTierBadge: document.getElementById("swagTierBadge"),
  basePointsValue: document.getElementById("basePointsValue"),
  bonusPointsValue: document.getElementById("bonusPointsValue"),
  totalBadgesCount: document.getElementById("totalBadgesCount"),
  milestoneBadge: document.getElementById("milestoneBadge"),
  milestoneBadgeText: document.getElementById("milestoneBadgeText"),

  gameBadgesCount: document.getElementById("gameBadgesCount"),
  gameBadgesPts: document.getElementById("gameBadgesPts"),
  skillBadgesCount: document.getElementById("skillBadgesCount"),
  skillBadgesPts: document.getElementById("skillBadgesPts"),
  triviaBadgesCount: document.getElementById("triviaBadgesCount"),
  triviaBadgesPts: document.getElementById("triviaBadgesPts"),
  milestonePointsValue: document.getElementById("milestonePointsValue"),
  milestoneProgressText: document.getElementById("milestoneProgressText"),

  milestoneProgressContainer: document.getElementById("milestoneProgressContainer"),
  progressTitle: document.getElementById("progressTitle"),
  progressPct: document.getElementById("progressPct"),
  progressBarFill: document.getElementById("progressBarFill"),
  lastUpdatedTime: document.getElementById("lastUpdatedTime"),
  engineVersionTag: document.getElementById("engineVersionTag"),
};

// State
let currentProfileUrl = "";
let currentIsFacilitator = true;
let isRefreshing = false;

// ============================================================================
// INITIALIZATION
// ============================================================================
document.addEventListener("DOMContentLoaded", async () => {
  setupEventListeners();
  await checkActiveTabForProfile();
  await loadStateAndInitialize();
});

function setupEventListeners() {
  elements.profileForm.addEventListener("submit", handleFormSubmit);
  elements.refreshBtn.addEventListener("click", () => triggerRefresh(true));
  elements.inlineRefreshBtn.addEventListener("click", () => triggerRefresh(true));
  elements.retryBtn.addEventListener("click", () => triggerRefresh(true));
  elements.changeProfileBtn.addEventListener("click", switchToSetupView);

  if (elements.useDetectedUrlBtn) {
    elements.useDetectedUrlBtn.addEventListener("click", () => {
      const detected = elements.autoDetectUrl.textContent.trim();
      if (detected) {
        elements.profileUrlInput.value = detected;
        elements.autoDetectBanner.classList.add("hidden");
        elements.profileForm.dispatchEvent(new Event("submit"));
      }
    });
  }

  elements.viewFullDashboardBtn.addEventListener("click", () => {
    const url = currentProfileUrl
      ? `${WEB_BASE_URL}/dashboard?url=${encodeURIComponent(currentProfileUrl)}`
      : `${WEB_BASE_URL}/dashboard`;
    openTab(url);
  });

  elements.openArcadeVerseBtn.addEventListener("click", () => {
    openTab(WEB_BASE_URL);
  });
}

function openTab(url) {
  if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({ url });
  } else {
    window.open(url, "_blank");
  }
}

// Active Tab Auto-Detection
async function checkActiveTabForProfile() {
  if (typeof chrome === "undefined" || !chrome.tabs || !chrome.tabs.query) return;

  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || tabs.length === 0) return;
      const activeUrl = tabs[0].url || "";
      const validation = validateProfileUrl(activeUrl);
      if (validation.valid && elements.autoDetectBanner) {
        elements.autoDetectUrl.textContent = validation.cleanUrl;
        if (!currentProfileUrl || currentProfileUrl !== validation.cleanUrl) {
          elements.autoDetectBanner.classList.remove("hidden");
        }
      }
    });
  } catch (err) {
    console.debug("Active tab check skipped:", err);
  }
}

// ============================================================================
// STORAGE & STATE
// ============================================================================
async function getStorageData(keys) {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(keys, resolve);
    } else {
      const result = {};
      for (const k of keys) {
        try {
          const val = localStorage.getItem(k);
          result[k] = val ? JSON.parse(val) : undefined;
        } catch {
          result[k] = undefined;
        }
      }
      resolve(result);
    }
  });
}

async function setStorageData(dataObj) {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set(dataObj, resolve);
    } else {
      for (const [k, v] of Object.entries(dataObj)) {
        try {
          localStorage.setItem(k, JSON.stringify(v));
        } catch {}
      }
      resolve();
    }
  });
}

async function loadStateAndInitialize() {
  const data = await getStorageData([
    STORAGE_KEYS.PROFILE_URL,
    STORAGE_KEYS.IS_FACILITATOR,
    STORAGE_KEYS.CACHED_DATA,
    STORAGE_KEYS.LAST_SUCCESS_TIME,
    STORAGE_KEYS.LAST_FETCH_TIME,
  ]);

  currentProfileUrl = data[STORAGE_KEYS.PROFILE_URL] || "";
  currentIsFacilitator = data[STORAGE_KEYS.IS_FACILITATOR] !== false; // default true
  const cachedData = data[STORAGE_KEYS.CACHED_DATA];
  const lastSuccessTime = data[STORAGE_KEYS.LAST_SUCCESS_TIME];
  const lastFetchTime = data[STORAGE_KEYS.LAST_FETCH_TIME] || 0;

  if (currentProfileUrl) {
    elements.profileUrlInput.value = currentProfileUrl;
    elements.isFacilitatorInput.checked = currentIsFacilitator;

    if (cachedData) {
      renderDashboard(cachedData, lastSuccessTime);
      showView("dashboard");
    } else {
      showView("dashboard");
    }

    const now = Date.now();
    if (!lastFetchTime || (now - lastFetchTime) > CACHE_MIN_REFRESH_INTERVAL_MS) {
      triggerRefresh(false);
    }
  } else {
    showView("setup");
  }
}

// ============================================================================
// URL VALIDATION
// ============================================================================
function validateProfileUrl(url) {
  if (!url || typeof url !== "string") {
    return { valid: false, message: "Profile URL is required." };
  }

  const trimmed = url.trim();

  try {
    const parsed = new URL(trimmed);

    if (parsed.protocol !== "https:") {
      return { valid: false, message: "URL must use secure HTTPS protocol." };
    }

    const host = parsed.hostname.toLowerCase();
    const validHosts = [
      "www.cloudskillsboost.google",
      "cloudskillsboost.google",
      "www.skills.google",
      "skills.google",
    ];

    if (!validHosts.includes(host)) {
      return {
        valid: false,
        message: "Only Google Cloud Skills Boost domains (skills.google or cloudskillsboost.google) are supported.",
      };
    }

    if (!parsed.pathname.includes("/public_profiles/")) {
      return {
        valid: false,
        message: "Invalid format. Profile URL must contain '/public_profiles/'.",
      };
    }

    return { valid: true, cleanUrl: trimmed };
  } catch {
    return { valid: false, message: "Please enter a valid URL." };
  }
}

// ============================================================================
// EVENT HANDLERS
// ============================================================================
async function handleFormSubmit(e) {
  e.preventDefault();
  clearInputError();

  const urlInput = elements.profileUrlInput.value.trim();
  const isFacilitator = elements.isFacilitatorInput.checked;

  const validation = validateProfileUrl(urlInput);
  if (!validation.valid) {
    showInputError(validation.message);
    return;
  }

  currentProfileUrl = validation.cleanUrl;
  currentIsFacilitator = isFacilitator;

  await setStorageData({
    [STORAGE_KEYS.PROFILE_URL]: currentProfileUrl,
    [STORAGE_KEYS.IS_FACILITATOR]: currentIsFacilitator,
  });

  setButtonLoading(true);
  showView("dashboard");
  await triggerRefresh(true);
  setButtonLoading(false);
}

function switchToSetupView() {
  clearStatusBanner();
  showView("setup");
}

function showView(view) {
  if (view === "setup") {
    elements.setupView.classList.remove("hidden");
    elements.dashboardView.classList.add("hidden");
  } else {
    elements.setupView.classList.add("hidden");
    elements.dashboardView.classList.remove("hidden");
  }
}

function showInputError(msg) {
  elements.inputError.textContent = msg;
  elements.inputError.classList.remove("hidden");
}

function clearInputError() {
  elements.inputError.textContent = "";
  elements.inputError.classList.add("hidden");
}

function setButtonLoading(loading) {
  const text = elements.calculateSubmitBtn.querySelector(".btn-text");
  const spinner = elements.calculateSubmitBtn.querySelector(".btn-spinner");
  if (loading) {
    text.classList.add("hidden");
    spinner.classList.remove("hidden");
    elements.calculateSubmitBtn.disabled = true;
  } else {
    text.classList.remove("hidden");
    spinner.classList.add("hidden");
    elements.calculateSubmitBtn.disabled = false;
  }
}

// ============================================================================
// API FETCH & REFRESH LOGIC
// ============================================================================
async function fetchCalculation(url, isFacilitator) {
  const query = `profileUrl=${encodeURIComponent(url)}&isFacilitator=${encodeURIComponent(String(isFacilitator))}`;

  async function doFetch(endpoint) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 20000);

    try {
      const res = await fetch(`${endpoint}?${query}`, {
        method: "GET",
        signal: controller.signal,
        headers: { "Accept": "application/json" },
      });
      clearTimeout(timeoutId);

      if (!res.ok) {
        let msg = `Server returned HTTP ${res.status}`;
        try {
          const errData = await res.json();
          if (errData && errData.error) msg = errData.error;
        } catch {}
        throw new Error(msg);
      }

      return await res.json();
    } catch (err) {
      clearTimeout(timeoutId);
      throw err;
    }
  }

  try {
    return await doFetch(API_PRIMARY);
  } catch (primaryErr) {
    try {
      return await doFetch(API_LOCAL_FALLBACK);
    } catch {
      throw primaryErr;
    }
  }
}

async function triggerRefresh(isManual = false) {
  if (isRefreshing || !currentProfileUrl) return;

  isRefreshing = true;
  setRefreshSpinner(true);
  clearStatusBanner();

  await setStorageData({ [STORAGE_KEYS.LAST_FETCH_TIME]: Date.now() });

  try {
    const result = await fetchCalculation(currentProfileUrl, currentIsFacilitator);

    if (!result || !result.points) {
      throw new Error("Invalid response format received from server.");
    }

    const now = new Date().toISOString();

    await setStorageData({
      [STORAGE_KEYS.CACHED_DATA]: result,
      [STORAGE_KEYS.LAST_SUCCESS_TIME]: now,
    });

    renderDashboard(result, now);
    clearStatusBanner();
  } catch (err) {
    console.warn("[ArcadeVerse Extension] Refresh error:", err);

    const stored = await getStorageData([
      STORAGE_KEYS.CACHED_DATA,
      STORAGE_KEYS.LAST_SUCCESS_TIME,
    ]);

    const cached = stored[STORAGE_KEYS.CACHED_DATA];
    const lastTime = stored[STORAGE_KEYS.LAST_SUCCESS_TIME];

    if (cached) {
      renderDashboard(cached, lastTime);
      const timeStr = lastTime ? formatRelativeTime(lastTime) : "earlier";
      showStatusBanner(`Showing saved data (${timeStr}). Server unavailable.`, false);
    } else {
      let friendlyError = err.message || "Failed to calculate points.";
      if (friendlyError.includes("Failed to fetch") || friendlyError.includes("abort")) {
        friendlyError = "Network connection timeout. Please check internet connection.";
      }
      showStatusBanner(friendlyError, true);
    }
  } finally {
    isRefreshing = false;
    setRefreshSpinner(false);
  }
}

function setRefreshSpinner(spinning) {
  const icon = elements.refreshBtn.querySelector(".spin-icon");
  if (spinning) {
    icon.classList.add("spinning");
    elements.inlineRefreshBtn.textContent = "Syncing...";
    elements.inlineRefreshBtn.disabled = true;
  } else {
    icon.classList.remove("spinning");
    elements.inlineRefreshBtn.textContent = "Refresh";
    elements.inlineRefreshBtn.disabled = false;
  }
}

function showStatusBanner(msg, isError = false) {
  elements.statusMessage.textContent = msg;
  elements.statusBanner.classList.remove("hidden", "error");
  if (isError) elements.statusBanner.classList.add("error");
}

function clearStatusBanner() {
  elements.statusBanner.classList.add("hidden", "error");
  elements.statusMessage.textContent = "";
}

function getSwagTier(totalPoints) {
  if (totalPoints >= 120) return { name: "Legend", minPoints: 120 };
  if (totalPoints >= 95) return { name: "Champion", minPoints: 95 };
  if (totalPoints >= 75) return { name: "Ranger", minPoints: 75 };
  if (totalPoints >= 50) return { name: "Trooper", minPoints: 50 };
  return { name: "Participant", minPoints: 0 };
}

// ============================================================================
// DASHBOARD RENDERING (SERVER-VERIFIED SECURE API INTEGRATION)
// ============================================================================
function renderDashboard(data, lastUpdatedIso) {
  const profile = data.profileData || {};
  const points = data.points || { total: 0, gameBadges: 0, skillBadges: 0, triviaBadges: 0, milestonePoints: 0 };
  const milestoneProgress = data.milestoneProgress || {};
  const totalPoints = points.total || 0;
  const swagTier = getSwagTier(totalPoints);

  const metrics = {
    name: profile.name || "Arcade Participant",
    memberSince: profile.memberSince || "Verified Public Profile",
    photoUrl: profile.photoUrl,
    league: profile.league || "Standard",
    totalBadges: (data.badges && data.badges.length) || 0,
    skillBadgesCount: Math.round((points.skillBadges || 0) * 2),
    gameBadgesCount: Math.round(points.gameBadges || 0),
    triviaBadgesCount: Math.round(points.triviaBadges || 0),
    basePoints: (points.gameBadges || 0) + (points.triviaBadges || 0) + (points.skillBadges || 0),
    milestonePoints: points.milestonePoints || 0,
    totalPoints: totalPoints,
    currentMilestone: milestoneProgress.currentMilestone || 0,
    milestoneProgressPct: milestoneProgress.progress || 0,
    swagTier: swagTier,
    engineVersion: "2026.1",
  };

  // User Header
  elements.userName.textContent = metrics.name;
  elements.userMemberSince.textContent = metrics.memberSince
    ? `Member since ${metrics.memberSince}`
    : "Verified Public Profile";

  if (elements.userLeagueBadge) {
    elements.userLeagueBadge.textContent = metrics.league ? `${metrics.league} League` : "Standard";
  }

  if (metrics.photoUrl) {
    elements.userAvatar.src = metrics.photoUrl;
  } else {
    elements.userAvatar.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(metrics.name || "User")}&background=9333ea&color=fff&size=80&bold=true`;
  }

  // Total Points & Swag Tier
  elements.totalPointsValue.textContent = metrics.totalPoints;
  if (elements.swagTierBadge) {
    elements.swagTierBadge.textContent = metrics.swagTier.name;
  }

  // Sub Breakdown (Base + Milestone Bonus + Total Badges)
  if (elements.basePointsValue) elements.basePointsValue.textContent = metrics.basePoints;
  if (elements.bonusPointsValue) elements.bonusPointsValue.textContent = `+${metrics.milestonePoints}`;
  if (elements.totalBadgesCount) elements.totalBadgesCount.textContent = metrics.totalBadges;

  // Milestone Badge
  const curMilestone = metrics.currentMilestone;
  if (curMilestone > 0) {
    elements.milestoneBadge.classList.remove("hidden");
    const label = curMilestone === 4 ? "Ultimate Milestone 🏆" : `Milestone ${curMilestone} Reached`;
    elements.milestoneBadgeText.textContent = label;
  } else {
    elements.milestoneBadge.classList.add("hidden");
  }

  // Metrics Grid
  elements.gameBadgesCount.textContent = metrics.gameBadgesCount;
  elements.gameBadgesPts.textContent = `${(points.gameBadges || 0).toFixed(1)} pts (1 pt/ea)`;

  elements.skillBadgesCount.textContent = metrics.skillBadgesCount;
  elements.skillBadgesPts.textContent = `${(points.skillBadges || 0).toFixed(1)} pts (0.5 pt/ea)`;

  elements.triviaBadgesCount.textContent = metrics.triviaBadgesCount;
  elements.triviaBadgesPts.textContent = `${(points.triviaBadges || 0).toFixed(1)} pts (1 pt/ea)`;

  elements.milestonePointsValue.textContent = `+${metrics.milestonePoints}`;
  elements.milestoneProgressText.textContent = curMilestone > 0
    ? `Milestone ${curMilestone} Bonus`
    : "Facilitator Cohort Bonus";

  // Progress Bar
  if (currentIsFacilitator && milestoneProgress.progress !== undefined) {
    elements.milestoneProgressContainer.classList.remove("hidden");
    const pct = Math.min(100, Math.max(0, Math.round(metrics.milestoneProgressPct)));
    elements.progressPct.textContent = `${pct}%`;
    elements.progressBarFill.style.width = `${pct}%`;
    elements.progressTitle.textContent = curMilestone >= 4
      ? "Ultimate Milestone Completed!"
      : `Next Milestone Progress (${pct}%)`;
  } else {
    elements.milestoneProgressContainer.classList.add("hidden");
  }

  // Last Updated & Engine Version Tag
  elements.lastUpdatedTime.textContent = lastUpdatedIso
    ? `Updated: ${formatRelativeTime(lastUpdatedIso)}`
    : "Just now";

  if (elements.engineVersionTag) {
    elements.engineVersionTag.textContent = `Engine v${metrics.engineVersion}`;
  }
}

function formatRelativeTime(isoString) {
  try {
    const diffSec = Math.floor((Date.now() - new Date(isoString).getTime()) / 1000);
    if (diffSec < 15) return "Just now";
    if (diffSec < 60) return `${diffSec}s ago`;
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return new Date(isoString).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  } catch {
    return "Recently";
  }
}
