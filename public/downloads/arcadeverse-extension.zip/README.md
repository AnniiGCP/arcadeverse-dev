# ArcadeVerse — Chrome Browser Extension (Manifest V3)

> **Arcade Points Calculator for Google Cloud Skills Boost Participants**

The official browser companion extension for [ArcadeVerse](https://arcadeverse.vercel.app/). Calculate and inspect your Google Cloud Arcade points, game & skill badge tallies, and Facilitator cohort milestones directly from your browser toolbar without having to open the full website every time.

---

## Features

- **Instant Arcade Points Calculation:** Fetches verified points from the official ArcadeVerse API using your public Google Cloud Skills Boost profile URL.
- **Local Persistence & Privacy:** Remembers your profile URL and last verified points locally in `chrome.storage.local`. Never requests Google passwords or authentication cookies.
- **Automatic & Manual Refresh:**
  - Automatically queries the API when opening the extension popup (with intelligent 25s deduplication).
  - Immediately displays the most recent cached result if offline or while a sync is in progress.
  - On network or rate limit failure, preserves the last valid calculation with a clear "cached data" indicator.
  - Manual **Refresh** button for on-demand synchronization.
- **Badge Breakdown:**
  - Arcade Game Badges (1.0 Pt each)
  - Skill Badges (0.5 Pts each)
  - Trivia Challenges (1.0 Pt each)
  - Facilitator Cohort Milestone Bonuses (+5 to +45 Pts)
- **Deep Links to Full Experience:** One-click navigation to the full ArcadeVerse Dashboard with your saved profile pre-loaded.

---

## How to Install Locally (Unpacked Extension)

You can load and test this extension in any Chromium-based browser (Google Chrome, Brave, Microsoft Edge, Arc, Opera) in under a minute:

1. **Open the Extensions Page:**
   - Chrome / Brave: Navigate to `chrome://extensions/`
   - Microsoft Edge: Navigate to `edge://extensions/`
2. **Enable Developer Mode:**
   - Toggle the **Developer mode** switch in the top-right corner of the extensions page.
3. **Load Unpacked Extension:**
   - Click the **"Load unpacked"** button in the top-left toolbar.
   - In the folder picker dialog, select the `extension` directory inside this repository:
     ```
     f:\test workspace\dev\extension
     ```
4. **Pin to Toolbar:**
   - Click the puzzle piece icon (Extensions) in your browser toolbar.
   - Click the pin icon next to **ArcadeVerse — Arcade Points Calculator**.
5. **Start Calculating:**
   - Click the ArcadeVerse icon in your browser toolbar.
   - Paste your public Google Cloud Skills Boost profile URL (e.g. `https://www.skills.google/public_profiles/...`).
   - Click **Calculate & Save Profile**.

---

## Architecture & Permissions

- **Manifest V3:** Adheres to modern Chromium security requirements.
- **Permissions:**
  - `storage`: Strictly used to store your public profile URL and locally cached calculation results in `chrome.storage.local`.
- **Host Permissions:**
  - `https://arcadeverse.vercel.app/*`: Accesses the production calculation API.
  - `http://localhost:3001/*` and `http://localhost:5173/*`: Local development fallbacks when developing or testing locally.
- **Zero Third-Party Trackers:** No analytics or third-party tracking scripts are bundled in the extension.

---

## File Structure

```
extension/
├── manifest.json       # Manifest V3 extension configuration
├── popup.html          # Lightweight popup UI markup
├── popup.css           # Custom dark theme styling matching ArcadeVerse design system
├── popup.js            # Validation, chrome.storage caching, auto-refresh, and API integration
├── icons/              # Extension icons (16px, 48px, 128px)
└── README.md           # Documentation and setup instructions
```
